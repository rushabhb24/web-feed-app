import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/prisma"

export async function POST(req: Request, { params }: { params: { postId: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const like = await prisma.like.create({
    data: {
      postId: params.postId,
      userId: session.user.id,
    },
  })

  return NextResponse.json(like)
}

export async function DELETE(req: Request, { params }: { params: { postId: string } }) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  await prisma.like.delete({
    where: {
      postId_userId: {
        postId: params.postId,
        userId: session.user.id,
      },
    },
  })

  return new NextResponse(null, { status: 204 })
}

