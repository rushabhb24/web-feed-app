import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/prisma"

export async function GET() {
  const posts = await prisma.post.findMany({
    include: {
      author: {
        include: {
          profile: true,
        },
      },
      comments: {
        include: {
          author: true,
        },
      },
      likes: true,
    },
    orderBy: {
      createdAt: "desc",
    },
  })

  return NextResponse.json(posts)
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  const json = await req.json()

  const post = await prisma.post.create({
    data: {
      content: json.content,
      image: json.image,
      video: json.video,
      authorId: session.user.id,
    },
    include: {
      author: {
        include: {
          profile: true,
        },
      },
      comments: {
        include: {
          author: true,
        },
      },
      likes: true,
    },
  })

  return NextResponse.json(post)
}

