import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"
import PostFeed from "@/components/post-feed"
import CreatePost from "@/components/create-post"

export default async function Home() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/login")
  }

  return (
    <main className="container mx-auto max-w-2xl py-10">
      <CreatePost />
      <PostFeed />
    </main>
  )
}

