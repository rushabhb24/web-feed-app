"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ImagePlus, Loader2, Video } from "lucide-react"

export default function CreatePost() {
  const router = useRouter()
  const [content, setContent] = useState("")
  const [media, setMedia] = useState<File | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      let mediaUrl = ""
      if (media) {
        const formData = new FormData()
        formData.append("file", media)
        const uploadRes = await fetch("/api/upload", {
          method: "POST",
          body: formData,
        })
        const { url } = await uploadRes.json()
        mediaUrl = url
      }

      const response = await fetch("/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content,
          image: media?.type.startsWith("image/") ? mediaUrl : null,
          video: media?.type.startsWith("video/") ? mediaUrl : null,
        }),
      })

      if (response.ok) {
        setContent("")
        setMedia(null)
        router.refresh()
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <form onSubmit={handleSubmit}>
        <CardContent className="pt-4">
          <Textarea
            placeholder="What's on your mind?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px]"
          />
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => document.getElementById("media-upload")?.click()}
            >
              <ImagePlus className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="outline"
              size="icon"
              onClick={() => document.getElementById("media-upload")?.click()}
            >
              <Video className="h-4 w-4" />
            </Button>
            <input
              id="media-upload"
              type="file"
              accept="image/*,video/*"
              className="hidden"
              onChange={(e) => setMedia(e.target.files?.[0] || null)}
            />
          </div>
          <Button type="submit" disabled={!content.trim() || isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Post
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}

