"use client"

import { useState } from "react"
import Image from "next/image"
import { useSession } from "next-auth/react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Heart, MessageCircle, Share2 } from "lucide-react"

export default function PostCard({ post }) {
  const { data: session } = useSession()
  const [isLiked, setIsLiked] = useState(post.likes.some((like) => like.userId === session?.user?.id))
  const [likesCount, setLikesCount] = useState(post.likes.length)
  const [comment, setComment] = useState("")

  const handleLike = async () => {
    const response = await fetch(`/api/posts/${post.id}/like`, {
      method: isLiked ? "DELETE" : "POST",
    })

    if (response.ok) {
      setIsLiked(!isLiked)
      setLikesCount(isLiked ? likesCount - 1 : likesCount + 1)
    }
  }

  const handleComment = async (e) => {
    e.preventDefault()

    const response = await fetch(`/api/posts/${post.id}/comment`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ content: comment }),
    })

    if (response.ok) {
      setComment("")
      // Refresh post data to show new comment
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-4">
        <Avatar>
          <AvatarImage src={post.author.profile?.image} />
          <AvatarFallback>{post.author.name[0]}</AvatarFallback>
        </Avatar>
        <div>
          <p className="font-semibold">{post.author.name}</p>
          <p className="text-sm text-muted-foreground">{new Date(post.createdAt).toLocaleDateString()}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p>{post.content}</p>
        {post.image && (
          <div className="relative aspect-video">
            <Image src={post.image || "/placeholder.svg"} alt="Post image" fill className="object-cover rounded-lg" />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <div className="flex items-center gap-4 w-full">
          <Button variant="ghost" size="sm" className="flex items-center gap-1" onClick={handleLike}>
            <Heart className={isLiked ? "fill-red-500 stroke-red-500" : ""} />
            {likesCount}
          </Button>
          <Button variant="ghost" size="sm" className="flex items-center gap-1">
            <MessageCircle />
            {post.comments.length}
          </Button>
          <Button variant="ghost" size="sm" className="flex items-center gap-1">
            <Share2 />
          </Button>
        </div>
        <form onSubmit={handleComment} className="flex items-center gap-2 w-full">
          <Input placeholder="Add a comment..." value={comment} onChange={(e) => setComment(e.target.value)} />
          <Button type="submit" size="sm">
            Post
          </Button>
        </form>
      </CardFooter>
    </Card>
  )
}

