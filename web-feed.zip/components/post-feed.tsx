"use client"

import { useEffect, useState } from "react"
import type { Post, User, Comment, Like } from "@prisma/client"
import PostCard from "./post-card"

type PostWithAuthorAndInteractions = Post & {
  author: User
  comments: (Comment & { author: User })[]
  likes: Like[]
}

export default function PostFeed() {
  const [posts, setPosts] = useState<PostWithAuthorAndInteractions[]>([])

  useEffect(() => {
    const fetchPosts = async () => {
      const response = await fetch("/api/posts")
      const data = await response.json()
      setPosts(data)
    }

    fetchPosts()
  }, [])

  return (
    <div className="space-y-8 mt-8">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  )
}

